package ce.mmu.siteuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiteuserApplicationTests {

	@Test
	void contextLoads() {
	}

}
