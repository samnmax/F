package ce.mmu.siteuser.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import ce.mmu.siteuser.domain.ArticleDTO;
import ce.mmu.siteuser.domain.SiteUserDTO;
import ce.mmu.siteuser.repository.SiteUserRepository;
import ce.mmu.siteuser.repository.Article;
import ce.mmu.siteuser.repository.ArticleHeader;
import ce.mmu.siteuser.repository.ArticleRepository;
import ce.mmu.siteuser.repository.SiteUser;

@Service
public class SiteUserService {
	@Autowired
    private SiteUserRepository userRepository;
	@Autowired
	private ArticleRepository articleRepository;

    public void save(SiteUserDTO dto) {
        SiteUser user = new SiteUser(dto.getName(), dto.getEmail(), dto.getPasswd());
        userRepository.save(user);
    }
    
    public void save(ArticleDTO dto) {
    	Article article = new Article();
    	article.setAuthor(dto.getAuthor());
    	article.setTitle(dto.getTitle());
    	article.setContents(dto.getContents());
    	articleRepository.save(article);
    }
    
    public Iterable<Article> getArticleAll() {
        return articleRepository.findAll();
    }
    
    public Page<ArticleHeader> getArticleHeaders(Pageable pageable) {
    	return articleRepository.findArticleHeaders(pageable);
    }
    
    public Iterable<SiteUser> getAll() {
        return userRepository.findAll();
    }
    
    public SiteUser findByEmail(String email) {
    	return userRepository.findByEmail(email);
    }
    
    public Article getArticle(Long num) {
    	return articleRepository.getReferenceById(num);
    }
}
