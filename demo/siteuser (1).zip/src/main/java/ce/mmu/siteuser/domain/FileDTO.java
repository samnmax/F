package ce.mmu.siteuser.domain;

import lombok.Data;

@Data
public class FileDTO {
	private String fileName;
	private String contentType;
}
