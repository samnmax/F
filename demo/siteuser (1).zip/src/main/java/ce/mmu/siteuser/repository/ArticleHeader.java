package ce.mmu.siteuser.repository;

public interface ArticleHeader {
	Long getNum();
	String getTitle();
	String getAuthor();
}
