package ce.mmu.siteuser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiteuserApplication {

	public static void main(String[] args) {
		SpringApplication.run(SiteuserApplication.class, args);
	}

}
