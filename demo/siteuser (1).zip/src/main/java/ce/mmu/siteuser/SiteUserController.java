package ce.mmu.siteuser;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ce.mmu.siteuser.domain.SiteUserDTO;
import ce.mmu.siteuser.repository.SiteUser;
import ce.mmu.siteuser.service.SiteUserService;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/siteuser/*")
public class SiteUserController {

    @Autowired
    private SiteUserService userService;

    // 관리자 암호코드 (실제 운영에선 환경변수/설정파일로 관리 권장)
    private static final String ADMIN_SECRET_CODE = "ADMIN";

    @GetMapping("/")
    public String start() {
        return "start";
    }

    @GetMapping("/login")
    public String loginForm() {
        return "login";
    }

    @PostMapping("/login")
    public String loginUser(SiteUserDTO dto, HttpSession session, RedirectAttributes rd) {
        SiteUser user = userService.findByEmail(dto.getEmail());
        if (user != null) {
            if (dto.getPasswd().equals(user.getPasswd())) {
                session.setAttribute("email", dto.getEmail());
                // 로그인 시 권한 정보도 세션에 저장 (선택)
                session.setAttribute("role", user.getRole());
                return "login_done";
            }
        }
        rd.addFlashAttribute("reason", "wrong password");
        return "redirect:/error";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "login";
    }

    @GetMapping("/signup")
    public String singnup() {
        return "signup_input";
    }

    @PostMapping("/signup")
    public String signup(
            SiteUserDTO user,
            @RequestParam(name = "adminCode", required = false) String adminCode,
            RedirectAttributes rd
    ) {
        // 관리자 암호코드 검증
        if (adminCode != null && !adminCode.isEmpty()) {
            if (!adminCode.equals(ADMIN_SECRET_CODE)) {
                rd.addFlashAttribute("reason", "wrong admincode");
                return "redirect:/error";
            }
            user.setRole("ADMIN"); // 관리자 권한 부여
        } else {
            user.setRole("USER"); // 일반 사용자 권한 부여
        }
        userService.save(user);
        return "signup_done";
    }

    @GetMapping("/all")
    @ResponseBody
    public Iterable<SiteUser> getAllUsers() {
        return userService.getAll();
    }

    @GetMapping("/all2")
    public String getAllUsers(Model model) {
        Iterable<SiteUser> users = userService.getAll();
        model.addAttribute("users", users);
        return "user_list";
    }

    @GetMapping("/find")
    public String find() {
        return "find_user";
    }

    @PostMapping("/find")
    public String findUser(
            @RequestParam(name = "email") String email,
            HttpSession session,
            Model model,
            RedirectAttributes rd
    ) {
        SiteUser user = userService.findByEmail(email);
        if (user != null) {
            model.addAttribute("user", user);
            return "find_done";
        }
        rd.addFlashAttribute("reason", "wrong email");
        return "redirect:/error";
    }
}
