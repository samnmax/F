package ce.mmu.siteuser;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ce.mmu.siteuser.domain.ArticleDTO;
import ce.mmu.siteuser.domain.FileDTO;
import ce.mmu.siteuser.repository.Article;
import ce.mmu.siteuser.repository.ArticleHeader;
import ce.mmu.siteuser.repository.FileRepository;
import ce.mmu.siteuser.repository.SiteFile;
import ce.mmu.siteuser.service.SiteUserService;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/siteuser/*")
public class ArticleController {

    @Autowired
    private SiteUserService userService;

    @Value("${spring.servlet.multipart.location}")
    private String base;

    @Autowired
    private FileRepository fileRepository;

    @GetMapping("bbs/read")
    public String readArticle(@RequestParam(name = "num") Long num, Model model, HttpSession session) {
        Article article = userService.getArticle(num);
        model.addAttribute("article", article);
        return "/bbs/article";
    }

    @GetMapping("bbs/write")
    public String bbsForm() {
        return "/bbs/new_article";
    }

    @PostMapping("bbs/write")
    public String addArticle(ArticleDTO dto) {
        userService.save(dto);
        return "/bbs/saved";
    }

    @GetMapping("bbs")
    public String getAllArticles(@RequestParam(name = "pno", defaultValue = "0") int pno,
            Model model, HttpSession session, RedirectAttributes rd) {
        String email = (String) session.getAttribute("email");
        if (email == null) {
            rd.addFlashAttribute("reason", "login required");
            return "redirect:/error";
        }
        int pageSize = 2;
        Pageable paging = PageRequest.of(pno, pageSize, Sort.Direction.DESC, "num");
        Page<ArticleHeader> data = userService.getArticleHeaders(paging);
        model.addAttribute("articles", data);
        return "/bbs/articles";
    }

    @GetMapping("bbs/upload")
    public String visitUpload() {
        return "/bbs/upload_form";
    }

    @PostMapping("bbs/upload")
    public String upload(@RequestParam("file") MultipartFile file, Model model) throws IllegalStateException, IOException, InvalidFormatException {
        if (!file.isEmpty()) {
            // 1. 파일 저장
            String fileName = file.getOriginalFilename().replace(' ', '_');
            FileDTO dto = new FileDTO();
            dto.setFileName(fileName);
            dto.setContentType(file.getContentType());

            File uploadDir = new File(base);
            if (!uploadDir.exists()) uploadDir.mkdirs();

            File upfile = new File(base + File.separator + fileName);
            file.transferTo(upfile);

            SiteFile siteFile = new SiteFile();
            siteFile.setName(fileName);
            fileRepository.save(siteFile);
            model.addAttribute("file", dto);

            // 2. 엑셀 파싱 및 게시글 생성
            List<String> menuList = new ArrayList<>();
            try (Workbook workbook = new XSSFWorkbook(upfile)) {
                Sheet sheet = workbook.getSheetAt(0);
                for (Row row : sheet) {
                    if (row.getRowNum() == 0) continue; // 헤더 건너뜀
                    Cell cell = row.getCell(0);
                    if (cell != null) {
                        String menu = cell.getStringCellValue().trim();
                        if (!menu.isEmpty()) {
                            menuList.add(menu);
                        }
                    }
                }

                if (!menuList.isEmpty()) {
                    // 3. 랜덤 메뉴 선택
                    String randomMenu = menuList.get(new Random().nextInt(menuList.size()));
                    
                    // 4. 현재 시간 포맷팅
                    String uploadTime = LocalDateTime.now()
                        .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

                    // 5. 게시글 저장
                    ArticleDTO articleDTO = new ArticleDTO();
                    articleDTO.setTitle("메뉴 업로드 - " + uploadTime);
                    articleDTO.setAuthor("admin");
                    articleDTO.setContents("추천 메뉴: " + randomMenu);
                    userService.save(articleDTO);
                }
            }
        }
        return "/bbs/result";
    }

    @GetMapping("bbs/filelist")
    public String fileList(Model model) {
        Iterable<SiteFile> files = fileRepository.findAll();
        model.addAttribute("files", files);
        return "/bbs/file_list";
    }

    @GetMapping("bbs/download")
    public ResponseEntity<Resource> download(FileDTO dto) throws IOException {
        Path path = Paths.get(base + "/" + dto.getFileName());
        String contentType = Files.probeContentType(path);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentDisposition(
                ContentDisposition.builder("attachment").filename(dto.getFileName(), StandardCharsets.UTF_8).build());
        headers.add(HttpHeaders.CONTENT_TYPE, contentType);
        Resource res = new InputStreamResource(Files.newInputStream(path));
        return new ResponseEntity<>(res, headers, HttpStatus.OK);
    }
}
