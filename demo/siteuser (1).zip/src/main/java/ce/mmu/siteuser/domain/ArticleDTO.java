package ce.mmu.siteuser.domain;

import lombok.Data;

@Data
public class ArticleDTO {
	private String author;
	private String title;
	private String contents;
}
