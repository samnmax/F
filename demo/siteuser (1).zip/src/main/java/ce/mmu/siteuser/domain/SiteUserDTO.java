package ce.mmu.siteuser.domain;

import lombok.Data;

@Data
public class SiteUserDTO {
    private String name;
    private String email;
    private String passwd;
    private String role; // 추가: ADMIN/USER 구분용
}
