package ce.mmu.siteuser.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FileRepository extends JpaRepository<SiteFile, Long> {

}
